# -*- coding: utf-8 -*-


{
    'name': 'Test Module',
    'category': 'Website/Website',
    'summary': 'Custom',
    'version': '1.0',
    'description': """
        Test
        """,
    'depends': ['website'],
    'data': [
        'test.xml',
    ],
    'installable': True,
    'application': True,
}
