# -*- coding: utf-8 -*-

from . import res_config_settings
from . import ir_http
from . import res_partner
from . import res_users
