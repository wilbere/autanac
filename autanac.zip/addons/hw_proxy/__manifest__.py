# -*- coding: utf-8 -*-


{
    'name': 'Hardware Proxy',
    'category': 'Sales/Point Of Sale',
    'sequence': 6,
    'summary': 'Connect the Web Client to Hardware Peripherals',
    'description': """
Hardware Poxy
=============

Este módulo le permite utilizar de forma remota los periféricos conectados a este servidor.


""",
    'installable': False,
}
