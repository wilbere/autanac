# -*- coding: utf-8 -*-

{
    'name': 'Google Users',
    'category': 'Tools',
    'description': """
Integración de Google account al sistema
========================================
""",
    'depends': ['base_setup'],
    'data': [
        'data/google_account_data.xml',
    ],
}
