# -*- coding: utf-8 -*-


from . import base_gengo_translations
