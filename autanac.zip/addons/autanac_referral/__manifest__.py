# -*- coding: utf-8 -*-
{
    'name': "Base Autanac",
    'summary': """ referal """,
    'category': 'Hidden',
    'version': '1.0',
    'depends': ['base', 'web'],
    'data': [
        'views/templates.xml',
    ],
    'qweb': [
        "static/src/xml/systray.xml",
    ],
    'auto_install': True,
}
