# -*- coding: utf-8 -*-


from . import ir_qweb
from . import ir_http
from . import models
